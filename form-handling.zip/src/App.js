import React from 'react';
import './App.css';
import './bs.css';
import FormHandler from './components/FormHandler';

function App() {
  return (
    <div className="App">
      <FormHandler/>
    </div>
  );
}

export default App;
